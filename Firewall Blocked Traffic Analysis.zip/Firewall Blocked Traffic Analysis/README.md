# Firewall Blocked Traffic Analysis 🔥

## 📌 Project Overview

A SOC Analyst mini project using **Splunk** to analyze firewall-blocked traffic and identify suspicious source and target IP addresses.

## 🎯 Objective

- Identify the source IP generating the highest blocked events.
- Identify the targeted internal destination IP.
- Analyze blocked traffic patterns.
- Present the findings using Splunk.

## 🛠️ Tools Used

- Splunk Enterprise
- SPL
- Firewall Logs

## 🔍 SPL Queries

### 1. Blocked Traffic

```spl
index=main sourcetype=dos status=blocked
| table _time, src_ip, dest_ip
| sort -count
```

### 2. Attacking IP

```spl
index=main sourcetype=dos status=blocked
| top src_ip
| sort -count
```

### 3. Target IP

```spl
index=main sourcetype=dos status=blocked
| stats count by dest_ip
| sort -count
```

## 📊 Analysis

The firewall logs were uploaded into Splunk using:

- **Index:** `main`
- **Source Type:** `dos`
- **Status:** `blocked`

The analysis identifies the high-volume attacking source IP and the internal destination IP receiving the blocked traffic.

## 💡 Skills Demonstrated

- Splunk & SPL
- Firewall Log Analysis
- Source/Destination IP Investigation
- Security Event Analysis
- SOC Monitoring
- Dashboard Creation

## 🗣️ Interview Summary

> Used Splunk to analyze firewall-blocked traffic, identify the top attacking source IP and targeted internal systems, and present the findings through a security dashboard.
